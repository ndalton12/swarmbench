# Exact upper bound: max number of new symbols compatible with the deployed rev A/B ones (needs scipy). Run from repo root.
import sys,csv;sys.path.insert(0,'tools');import symlib
import numpy as np
from scipy.optimize import milp,LinearConstraint,Bounds
from scipy.sparse import lil_matrix
rows=list(csv.DictReader(open('protocol/commands.csv')))
dep=[symlib.from_str(r['symbol']) for r in rows if r['rev'] in('A','B') and r['symbol']]
print(len(dep))
fixed=dep+list(symlib.RESERVED.values())
c=[w for w in symlib.all_symbols() if w not in fixed and all(symlib.distance(w,f)>=4 for f in fixed)]
print(len(c))
pairs=[(i,j) for i in range(len(c)) for j in range(i+1,len(c)) if symlib.distance(c[i],c[j])<4]
A=lil_matrix((len(pairs),len(c)))
for k,(i,j) in enumerate(pairs):A[k,i]=1;A[k,j]=1
r=milp(-np.ones(len(c)),constraints=LinearConstraint(A.tocsr(),-np.inf,1),integrality=np.ones(len(c)),bounds=Bounds(0,1),options={'time_limit':600})
print(r.status,r.message,-r.fun, getattr(r,'mip_dual_bound',None))
