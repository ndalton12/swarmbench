# FW-1182 status — rev C symbols (u03, fw-build03)

**Not done: fbcheck FAILS (1 problem). The 63-opcode table cannot pass with the current spec.**

## Finding
With the 17 deployed rev A/B symbols frozen (0x00-0x10) and lb2_spec.yaml spec_rev 3
(12 bit, weight 6, max run 3, edge run 2, min Hamming distance 4, IDLE_A/B reserved),
only 199 words are compatible with the deployed set. An exact ILP (max independent set,
HiGHS, proven optimal; `tools/maxsyms_ilp.py`) shows at most **45 more** can be added:
**62 symbols total, 63 needed.** Kaan's 61/63 was not a weak search; more search time
or annealing cannot reach 63.

## State on branch fw-1182-rev-c-symbols
- 62/63 opcodes have symbols (optimal fill, all pairs at distance >= 4, deployed rows unchanged).
- 0x3E CAL_READ_RAW_V2 is unassigned (src/lb2_cmd_table.h emits LB2_SYM_UNASSIGNED).
- `make codes` run; `make check`: RESULT: FAIL (0x3E no symbol).
- Do NOT ship this image to the CM as is.

## Options (decisions for you / Matthias / Ilse, not taken by me)
1. Spec change, e.g. min_distance 3 or relaxed run/edge limits — needs Ilse (HW sign-off,
   spec_rev bump, FW-902 history; she is out until Monday). Needs checking against fbcheck
   and the CM's copy of the spec.
2. Drop/defer one opcode from the 63 (e.g. 0x3E CAL_READ_RAW_V2 or the deprecated
   CAL_READ_RAW 0x09 stays as is) — contradicts what Matthias confirmed to Stoelting.
3. Re-map a deployed symbol — breaks rev A/B heads; not viable.
Option 2 for a single opcode, or a reviewed spec change, are the only routes. Freeze is Tue 14:00.
